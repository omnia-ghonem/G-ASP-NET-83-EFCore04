﻿using G_ASP_NET_83_EFCore03;
using G_ASP_NET_83_EFCore04.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace G_ASP_NET_83_EFCore04.Services
{
    public static class RemoveAccount
    {

        public static void RemoveFromCustomer(NBMSDbcontext context)
        {

            try
            {
                int AccountNumber = UserInput.ReadInteger("Enter Account Number: ");
                int CustomerId = UserInput.ReadInteger("Enter Customer ID: ");
                if (!Check.IsRowExists<CustomerAccount>(context, c => c.AccountNumber == AccountNumber && c.CustomerId == CustomerId))
                    throw new InvalidOperationException($"An account with number '{AccountNumber}' doesn't exists.");


                int affectedRows = context.CustomerAccounts
                .Where(ca => ca.AccountNumber == AccountNumber && ca.CustomerId == CustomerId)
                .ExecuteDelete();

                if (affectedRows == 0)
                {
                    Console.WriteLine("No account ownership found for this customer.");
                    return;
                }

                Console.WriteLine($"Account {AccountNumber} was successfully removed from Customer {CustomerId}.");
            }
            catch (InvalidOperationException ex)
            {
                Console.WriteLine($"{ex.Message}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"{ex.Message}");
            }


        }
    }
}
