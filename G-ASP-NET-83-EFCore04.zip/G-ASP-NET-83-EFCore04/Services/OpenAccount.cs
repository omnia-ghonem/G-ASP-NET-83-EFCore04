﻿using G_ASP_NET_83_EFCore03;
using G_ASP_NET_83_EFCore04.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace G_ASP_NET_83_EFCore04.Services
{
    public static class OpenAccount
    {
        public static void Add(NBMSDbcontext context)
        {
            try
            {
                int AccountNumber = UserInput.ReadInteger("Enter account Number: ");

                if (!Check.IsRowExists<Account>(context, c => c.AccountNumber == AccountNumber))
                {
                    decimal CurrentBalance = UserInput.ReadDecimal("Enter account Balance: ");
                    DateTime OpeningDate = DateTime.Today;
                    AccountType AccountType = UserInput.ReadType<AccountType>("Enter account Type: ");
                    Account newaccount = new Account { AccountNumber = AccountNumber, CurrentBalance = CurrentBalance, OpeningDate = OpeningDate, AccountType = AccountType };
                    EnrollRow.EnrollAccount(context, newaccount);
                    Console.WriteLine($"A new account of number {newaccount.AccountNumber} is added successfuly.");

                }
                else
                {
                    Console.WriteLine();
                    Console.WriteLine($"Account {AccountNumber} already exists.");

                }
                Console.WriteLine();
                int CutomerId = UserInput.ReadInteger("Enter Customer Id: ");
                OwnershipRole OwnershipRole = OwnershipRole.Primary;
                AccountStatus AccountStatus = UserInput.ReadTypebyChoice<AccountStatus>();
                DateTime OwnershipStartDate = DateTime.Today;


                CustomerAccount newcustomeraccount = new CustomerAccount { AccountNumber = AccountNumber, CustomerId = CutomerId, OwnershipRole = OwnershipRole };
                EnrollRow.EnrollCustomerAccount(context, newcustomeraccount);



            }
            catch (ArgumentException ex)
            {
                Console.WriteLine($"{ex.Message}");
            }
            catch (InvalidOperationException ex)
            {
                Console.WriteLine($"{ex.Message}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Unexpected Error: {ex.Message}");
            }


        }
    }
}
