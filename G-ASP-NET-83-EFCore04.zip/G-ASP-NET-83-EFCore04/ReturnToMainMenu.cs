﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace G_ASP_NET_83_EFCore04
{
    public static class ReturnToMainMenu
    {
        public static void Return()
        {
            Console.WriteLine("\nWhat would you like to do?");
            Console.WriteLine("1. Return to Main Menu");
            Console.WriteLine("0. Exit Application");

            while (true)
            {
                int choice = UserInput.ReadInteger("Enter choice (0 or 1): ");

                if (choice == 1)
                    return;

                if (choice == 0)
                {
                    Console.WriteLine("Thank you for using National Bank. Goodbye!");
                    Environment.Exit(0);
                }

                Console.WriteLine("Invalid choice. Enter 0 or 1.");
            }
        }
    }
}
